#!/usr/bin/env python
# coding: utf-8

# In[12]:


for num in range(2,200):
 if num>1:
        for i in range(2,num):
            if(num%i)==0:
                print(num,"NOt a prime number")
                break
        else:
            print(num,"prime number")
            
 else:
    print("not a prime number")


# In[ ]:





# In[ ]:




