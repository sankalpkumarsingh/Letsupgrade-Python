#!/usr/bin/env python
# coding: utf-8

# In[3]:



 alt = int(input("Enter The Altitude"))
if alt==1000:
    print("Safe t0 Land")
elif 1000< alt <5000:
    print("Bring Down to 1000")
else:
    print("Turn Around")
  


# In[ ]:




